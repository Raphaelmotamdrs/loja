function increaseQuantity(button) {
    var quantityElement = button.parentNode.querySelector('.quantity');
    var quantity = parseInt(quantityElement.innerText);
    quantity++;
    quantityElement.innerText = quantity;

    updateItemTotal(button);
    updateTotalPrice();
}

function decreaseQuantity(button) {
    var quantityElement = button.parentNode.querySelector('.quantity');
    var quantity = parseInt(quantityElement.innerText);
    if (quantity > 1) {
        quantity--;
        quantityElement.innerText = quantity;

        updateItemTotal(button);
        updateTotalPrice();
    }
}

function updateItemTotal(button) {
    var quantityElement = button.parentNode.querySelector('.quantity');
    var itemElement = button.parentNode.parentNode;
    var priceElement = itemElement.querySelector('.item-price');
    var totalElement = itemElement.querySelector('.item-total');
  
    var quantity = parseInt(quantityElement.innerText);
    var price = parseFloat(priceElement.innerText.replace('R$', ''));
    var itemTotal = quantity * price;
  
    totalElement.innerText = 'R$' + itemTotal.toFixed(2);
}

function updateTotalPrice() {
    var items = document.querySelectorAll('.item');
    var totalPrice = 0;

    items.forEach(function(item) {
        var totalElement = item.querySelector('.item-total');
        var itemTotal = parseFloat(totalElement.innerText.replace('R$', ''));
        totalPrice += itemTotal;
    });

    var totalPriceElement = document.getElementById('total-price');
    totalPriceElement.innerText = 'R$' + totalPrice.toFixed(2);
}   



function removeItem(button) {
    var item = button.parentNode;
    item.parentNode.removeChild(item);

    updateTotalPrice();
}